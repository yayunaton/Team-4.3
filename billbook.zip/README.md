# Team-4.3
Cornell cs3110sp23 Final Team Project

# Team Members:
  - Haoxuan Zou (hz252)
  - James Liu (zl293)
  - Yiyuan Chen (yc823)
  - Rachel Jiang (tj232)

# Notes:
Primary Executable: bin/main.ml
Backend Functions: lib/functions

remember to change functions.mli if changes are made to functions.ml
